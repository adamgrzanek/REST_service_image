import requests
import unittest
import json


class TestREST(unittest.TestCase):

    BASE = 'http://127.0.0.1:3000/'

    def test_1(self):
        url = self.BASE + 'augumentation/test'
        resp = requests.get(url)
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.json()['result'], 'test OK')


    def test_negative(self):
        # open example input
        with open('examples_input/example_input_1.txt', 'r') as file_1:
            input_file = json.loads(file_1.read())

        url = self.BASE + 'augumentation/negative'
        resp = requests.post(url, json=input_file)

        # open output file and compare with program output
        with open('examples_input/example_output_1.txt', 'r') as file_2:
            output_file = json.loads(file_2.read())

        self.assertEqual(resp.status_code, 200)
        self.assertEqual(output_file, json.loads(resp.text))


    def test_rotate(self):
        # open example input
        with open('examples_input/example_input_2.txt', 'r') as file_1:
            input_file = json.loads(file_1.read())

        url = self.BASE + 'augumentation/rotate?angle=180'
        resp = requests.post(url, json=input_file)

        # open output file and compare with program output
        with open('examples_input/example_output_2.txt', 'r') as file_2:
            output_file = json.loads(file_2.read())

        self.assertEqual(resp.status_code, 200)
        self.assertEqual(output_file, json.loads(resp.text))


    def test_crop(self):
        # open example input
        with open('examples_input/example_input_3.txt', 'r') as file_1:
            input_file = json.loads(file_1.read())

        url = self.BASE + 'augumentation/crop?start_x=10&start_y=606&end_x=590&end_y=760'
        resp = requests.post(url, json=input_file)

        # open output file and compare with program output
        with open('examples_input/example_output_3.txt', 'r') as file_2:
            output_file = json.loads(file_2.read())

        self.assertEqual(resp.status_code, 200)
        self.assertEqual(output_file, json.loads(resp.text))


if __name__ == '__main__':
    unittest.main(verbosity=2)
