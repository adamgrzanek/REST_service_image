1. Requirements (requirements.txt):
Open Your IDE (e.g. PyCharm), and open Recruitment_task_Adam_Grzanek directory as a new project.

Install requirements on your IDE

or

open cmd and change directory to Recruitment_task_Adam_Grzanek.
Activate venv.
Next paste below command to Your cmd.
"pip install -r requirements.txt"



2. Start application:

Open REST.py and run it on Your IDE (e.g. PyCharm)

or

open cmd and change directory to Recruitment_task_Adam_Grzanek.
Activate venv.
Next paste below command to Your cmd.
"python REST.py"

Expected result: "Running on http://127.0.0.1:3000/"



3. Start unittest (after completing step 2):

Open test.py and run it on Your IDE (e.g. PyCharm)

or

open cmd and change directory to Recruitment_task_Adam_Grzanek.
Activate venv.
Next paste below command to Your cmd.
"python -m unittest test.py -v"



4. Test application (after completing step 2):

Open testing platform (e.g. Postman).
Paste *path and add input data (a JSON with encoded base64 image).
Expected example input:
"{'encoded_image': '....encoded_base64_image....'}"

Example inputs and expected outputs are in the "examples_input" directory (Used for testing).
* Example paths:
(method: 'POST')
http://127.0.0.1:3000/augumentation/augumentation/negative
http://127.0.0.1:3000/augumentation/augumentation/compression
http://127.0.0.1:3000/augumentation/rotate?angle=180
http://127.0.0.1:3000/augumentation/resize?width=600&height=200
http://127.0.0.1:3000/augumentation/crop?start_x=0&start_y=200&end_x=200&end_y=400


Your decoded input and output image are in the "input_output_files" directory.

