import PIL
from PIL import Image


def negative_image(img_source):
    img = Image.open(img_source)
    img_width, img_height = img.size
    for i in range(img_width):
        for j in range(img_height):
            r,g,b=img.getpixel((i,j))
            r=255-r
            g=255-g
            b=255-b
            img.putpixel((i,j),(r,g,b))
    img.save('input_output_files/output_image.jpg', "JPEG")


def compression_image(img_source):
    img = PIL.Image.open(img_source)
    img_height, img_width = img.size
    img_compress = img.resize((img_height, img_width), PIL.Image.ANTIALIAS)
    img_compress.save('input_output_files/output_image.jpg')


def rotate_image(img_source, angle):
    img = Image.open(img_source)
    img_rotate = img.rotate(angle)
    img_rotate.save('input_output_files/output_image.jpg')


def resize_image(img_source, width, height):
    img = Image.open(img_source)
    img_resize = img.resize((width, height))
    img_resize.save('input_output_files/output_image.jpg')


def crop_image(img_source, start_x, start_y, end_x, end_y):
    img = Image.open(img_source)
    box = (start_x, start_y, end_x, end_y)
    img_crop = img.crop(box)
    img_crop.save('input_output_files/output_image.jpg')

