import base64
from flask import Flask
from flask import jsonify
from flask import request
from image_change import negative_image, compression_image, rotate_image, resize_image, crop_image


app = Flask(__name__)


def decode_source():
    # create decoded input image
    request_data = request.get_json()
    encoded_image = request_data["encoded_image"]
    with open('input_output_files/input_image.jpg', 'wb') as input_img:
        input_img.write(base64.b64decode(encoded_image))


def encode():
    # create encode output text
    with open("input_output_files/output_image.jpg", "rb") as output_file:
        global output_text
        output_text = base64.b64encode(output_file.read()).decode('utf-8')


@app.route('/augumentation/test', methods=['GET'])
def test():
    return jsonify(result='test OK')


@app.route('/augumentation/negative', methods=['POST'])
def negative():
    decode_source()
    negative_image('input_output_files/input_image.jpg')
    encode()
    return jsonify(modified_negative_image=output_text)


@app.route('/augumentation/compression', methods=['POST'])
def compression():
    decode_source()
    compression_image('input_output_files/input_image.jpg')
    encode()
    return jsonify(modified_compression_image=output_text)


# http://127.0.0.1:3000/augumentation/rotate?angle=45
@app.route('/augumentation/rotate', methods=['POST'])
def rotate():
    decode_source()
    angle = request.args.get('angle')
    rotate_image('input_output_files/input_image.jpg', float(angle))
    encode()
    return jsonify(modified_rotate_image=output_text)


# http://127.0.0.1:3000/augumentation/resize?width=600&height=200
@app.route('/augumentation/resize', methods=['POST'])
def resize():
    decode_source()
    width = int(request.args.get('width'))
    height = int(request.args.get('height'))
    resize_image('input_output_files/input_image.jpg', width, height)
    encode()
    return jsonify(modified_resize_image=output_text)


# http://127.0.0.1:3000/augumentation/crop?start_x=0&start_y=200&end_x=200&end_y=400
@app.route('/augumentation/crop', methods=['POST'])
def crop():
    decode_source()
    start_x = int(request.args.get('start_x'))
    start_y = int(request.args.get('start_y'))
    end_x = int(request.args.get('end_x'))
    end_y = int(request.args.get('end_y'))
    crop_image('input_output_files/input_image.jpg', start_x, start_y, end_x, end_y)
    encode()
    return jsonify(modified_crop_image=output_text)


app.run(debug=True, port=3000)
